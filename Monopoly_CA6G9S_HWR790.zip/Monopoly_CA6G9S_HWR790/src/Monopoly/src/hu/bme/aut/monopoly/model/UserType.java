package hu.bme.aut.monopoly.model;

import java.io.Serializable;


public enum UserType implements Serializable
{
    notRegistered, user, admin
}
