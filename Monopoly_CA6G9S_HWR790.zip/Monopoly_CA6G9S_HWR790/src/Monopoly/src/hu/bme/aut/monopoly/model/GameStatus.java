package hu.bme.aut.monopoly.model;

import java.io.Serializable;


public enum GameStatus implements Serializable
{
    init, inProgress, finished
}
