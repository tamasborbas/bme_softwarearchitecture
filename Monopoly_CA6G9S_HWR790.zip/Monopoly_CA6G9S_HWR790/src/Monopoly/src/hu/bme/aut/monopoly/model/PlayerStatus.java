package hu.bme.aut.monopoly.model;

import java.io.Serializable;


public enum PlayerStatus implements Serializable
{
    notAcceptedYet, refused, accepted, lost, win
}
